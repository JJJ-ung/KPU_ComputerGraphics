#pragma once

#include "CGameManager.h"
#include "CRenderer.h"
#include "CSceneManager.h"
#include "CKeyManager.h"
#include "CFrameManager.h"
#include "CTimeManager.h"
#include "CSoundManager.h"
#include "CShaderLoader.h"
