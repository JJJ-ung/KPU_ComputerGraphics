#pragma once

namespace OBJ
{
	enum ID { PLAYER1, PLAYER2, RULLET, 
						UI1, UI2,
						MAP, UI, END };
}

namespace COMPONENT
{
	enum ID { UPDATE, TEXTURE, BUFFER, END };
}

namespace SCENE
{
	enum ID { LOGO, SELECT, INGAME, RESULT, END };
}

namespace BUFFER_INDEX
{
	enum BUFFER { POSITION, TEXCOORD, NORMAL, END };
}

namespace RENDER
{
	enum ID { BACK, NONALPHA, ALPHA, UI, END };
}

namespace PLATFORM
{
	enum TYPE { TREE, STONE, DIY, GRASS, NPC, FRUIT, FISH, FOSSIL,INSECT, END };
}

namespace CAMERA
{
	enum STATE { FULL, PLAYER1, PLAYER2, PLAYER1_ANI, PLAYER2_ANI, END };
}

namespace GAME
{
	enum STATE { SELECT, RULLET, ANIMATION, END };
}
