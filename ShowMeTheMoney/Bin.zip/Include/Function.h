#pragma once

template <typename T>
void SafeDelete(T& ptr)
{
	if (ptr != nullptr)
	{
		delete ptr;
		ptr = nullptr;
	}
}

template <typename T>
void SafeDelete_Array(T& ptr)
{
	if (ptr)
	{
		delete[] ptr;
		ptr = nullptr;
	}
}

template<typename T>
bool CompareZ(T src, T dst)
{
	return src->vPos.z < dst->vPos.z;
}

template<typename T>
bool ComparebyZ(T src, T dst)
{
	return src->GetZ() < dst->GetZ();
}

template<typename T>
bool SortByIndex(T src, T dst)
{
	return src->iIndex < dst->iIndex;
}

template<typename T>
bool SortByItemIndex(T src, T dst)
{
	return src->iIndex < dst->iIndex;
}

class CStrCmp
{
public:
	CStrCmp() {};
	CStrCmp(const TCHAR* pString)
		:m_pString(pString)
	{}
	~CStrCmp() {};
public:
	template<typename T>
	bool operator()(T& rPair)
	{
		return !lstrcmp(m_pString, rPair.first);
	}
private:
	const TCHAR* m_pString;
};
